﻿using AutoMapper;
using WebApiMobileStore.Models;
using WebApiMobileStore.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiMobileStore.Models.Dto;

namespace WebApiMobileStore
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<ProductDto, Product>();
                config.CreateMap<Product, ProductDto>();

                config.CreateMap<SaleDto, Sale>();
                config.CreateMap<Sale, SaleDto>();

                config.CreateMap<ProfitReportDto, ProfitReport>();
                config.CreateMap<ProfitReport, ProfitReportDto>();
            });

            return mappingConfig;
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApiMobileStore.Migrations
{
    public partial class updateReportTableToDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CostPrice",
                table: "ProfitReports");

            migrationBuilder.RenameColumn(
                name: "SellingPrice",
                table: "ProfitReports",
                newName: "UnitsSold");

            migrationBuilder.AddColumn<double>(
                name: "Discount",
                table: "Sales",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<string>(
                name: "SaleMonth",
                table: "ProfitReports",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SaleYear",
                table: "ProfitReports",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Discount",
                table: "Sales");

            migrationBuilder.DropColumn(
                name: "SaleMonth",
                table: "ProfitReports");

            migrationBuilder.DropColumn(
                name: "SaleYear",
                table: "ProfitReports");

            migrationBuilder.RenameColumn(
                name: "UnitsSold",
                table: "ProfitReports",
                newName: "SellingPrice");

            migrationBuilder.AddColumn<double>(
                name: "CostPrice",
                table: "ProfitReports",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }
    }
}

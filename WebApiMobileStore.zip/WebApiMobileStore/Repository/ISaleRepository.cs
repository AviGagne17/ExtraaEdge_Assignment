﻿using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApiMobileStore.Models;
using WebApiMobileStore.Models.Dtos;

namespace WebApiMobileStore.Repository
{
    public interface ISaleRepository
    {
        Task<IEnumerable<SaleDto>> GetSaleRecordByDate(string fromDate, string toDate);
        Task<IEnumerable<ProfitReportDto>> GetSaleReportByMonth(int month, int year);

        Task<IEnumerable<ProfitReportDto>> GetSaleReportByMonthForSpecificProduct(int month, int year, int id);

        Task<SaleDto> AddSaleRecord(SaleDto saleDto);
        Task<SaleDto> UpdateSaleRecord(SaleDto saleDto);

        Task<bool> DeleteSaleRecord(int saleId);
    }
}

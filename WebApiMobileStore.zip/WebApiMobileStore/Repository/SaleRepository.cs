﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Authentication;
using System.Threading.Tasks;
using WebApiMobileStore.DbContexts;
using WebApiMobileStore.Models;
using WebApiMobileStore.Models.Dtos;

namespace WebApiMobileStore.Repository
{
    public class SaleRepository : ISaleRepository
    {
        private readonly ApplicationDbContext _db;
        private IMapper _mapper;

        public List<string> monthName = new List<string>() {"jan", "jan", "feb", "mar", "apr","may", "jun", "jul", "aug", "sep","oct","nov","dec"};
        public SaleRepository(ApplicationDbContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }
        public async Task<SaleDto> AddSaleRecord(SaleDto saleDto)
        {
            Sale sale = _mapper.Map<SaleDto, Sale>(saleDto);
            var product = _db.Products.FirstOrDefault(u => u.ProductId == sale.ProductId);

            if (sale.SaleId > 0 || product == null)
            {
                throw new InvalidOperationException();
            }
            else
            {
                sale.SaleDate = DateTime.Parse(sale.SaleDate).ToString("yyyyMMdd");
                _db.Sales.Add(sale);

                var report = _db.ProfitReports.FirstOrDefault(u => u.ProductId == sale.ProductId
                                && u.SaleMonth == monthName[Int32.Parse(sale.SaleDate.Substring(4, 2))]);

                if(report == null)
                {
                    report = new ProfitReport();
                    report.ProductId = product.ProductId;
                    report.ProductName = product.Name;
                    report.Discount = sale.Discount;
                    report.SaleMonth = monthName[Int32.Parse(sale.SaleDate.Substring(4, 2))];
                    report.SaleYear = Int32.Parse(sale.SaleDate.Substring(0, 4));
                    report.Profit = sale.SellingPrice - product.Price;
                    report.UnitsSold = 1;

                    _db.ProfitReports.Add(report);
                }
                else
                {
                    if(report.SaleMonth != monthName[Int32.Parse(sale.SaleDate.Substring(4, 2))])
                    { 
                    }
                    report.ProductId = product.ProductId;
                    report.ProductName = product.Name;
                    report.Discount += sale.Discount;
                    report.SaleMonth = monthName[Int32.Parse(sale.SaleDate.Substring(4, 2))];
                    report.SaleYear = Int32.Parse(sale.SaleDate.Substring(0, 4));
                    report.Profit += sale.SellingPrice - product.Price;
                    report.UnitsSold += 1;

                    _db.ProfitReports.Update(report);

                }

            }
            await _db.SaveChangesAsync();
            return _mapper.Map<Sale, SaleDto>(sale);
        }

        public async Task<bool> DeleteSaleRecord(int saleId)
        {
            try
            {
                Sale sale = await _db.Sales.FirstOrDefaultAsync(u => u.SaleId == saleId);
                if (sale == null)
                {
                    return false;
                }
                _db.Sales.Remove(sale);
                await _db.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<IEnumerable<SaleDto>> GetSaleRecordByDate(string fromDate, string toDate)
        {
            var startDate = Int32.Parse(DateTime.Parse(fromDate).ToString("yyyyMMdd"));
            var endDate = Int32.Parse(DateTime.Parse(toDate).ToString("yyyyMMdd"));

            var saleRecords = await _db.Sales.ToListAsync();

            var reqRecords = saleRecords.Where(u => Int32.Parse(u.SaleDate) < endDate
                                            && Int32.Parse(u.SaleDate) > startDate).ToList();

            return _mapper.Map<List<SaleDto>>(reqRecords);            
        }

        public async Task<ProfitReportDto> GetSaleReportByMonth(int monthNo, int year)
        {
            string month = "";
            try
            {
                

                if(monthNo > 12 && monthNo < 1)
                {
                    throw new InvalidOperationException();
                }

                month = monthName[monthNo];

            }
            catch(Exception ex)
            {
                throw new InvalidCredentialException();
            }

            var saleRecords = await _db.ProfitReports.ToListAsync();
            var reqRecords = saleRecords.Where(u => u.SaleMonth == month && u.SaleYear == year);

            ProfitReport reqRecordsCumm = new ProfitReport();
            foreach(var record in reqRecords )
            {
                reqRecordsCumm.Profit += record.Profit;
                reqRecordsCumm.Discount += record.Discount;
                reqRecordsCumm.UnitsSold += record.UnitsSold;

            }
            reqRecordsCumm.SaleMonth = month;
            reqRecordsCumm.SaleYear = year;

            return _mapper.Map<ProfitReportDto>(reqRecordsCumm);
        }

        public async Task<IEnumerable<ProfitReportDto>> GetSaleReportByMonthForSpecificProduct(int monthNo, int year, int id)
        {
            string month = "";
            try
            {

                var product = await _db.Products.FirstOrDefaultAsync(u => u.ProductId == id);
                if (monthNo > 12 && monthNo < 0 && product == null)
                {
                    throw new InvalidOperationException();
                }
                

                month = monthName[monthNo];

            }
            catch (Exception ex)
            {
                throw new InvalidCredentialException();
            }

            var saleRecords = await _db.ProfitReports.ToListAsync();
            var reqRecords = saleRecords.Where(u => u.SaleMonth == month && u.SaleYear == year && u.ProductId == id);

            return _mapper.Map<List<ProfitReportDto>>(reqRecords);
        }
        public async Task<SaleDto> UpdateSaleRecord(SaleDto saleDto)
        {
            Sale sale = _mapper.Map<SaleDto, Sale>(saleDto);
            if (sale.SaleId == 0)
            {
                throw new System.InvalidOperationException();
            }
            else
            {
                sale.SaleDate = DateTime.Parse(sale.SaleDate).ToString("yyyyMMdd");
                _db.Sales.Add(sale);
            }
            await _db.SaveChangesAsync();
            return _mapper.Map<Sale, SaleDto>(sale);

        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System;
using System.Linq;
using WebApiMobileStore.JwtHelperLib.Models;
using WebApiMobileStore.JwtHelperLib;
using WebApiMobileStore.Models.Dtos;
using WebApiMobileStore.Models.Dto;
using WebApiMobileStore.Repository;
using System.Threading.Tasks;

namespace WebApiMobileStore.Controllers
{
    [Route("api/authenticate")]
    public class AuthenticationController : ControllerBase
    {
        protected ResponseDto _response;

        public AuthenticationController()
        {
            this._response = new ResponseDto();
        }

        [HttpGet]
        public async Task<object> Get(string userName, string password)
        {
            await Task.Delay(1000);

            if (!userName.Equals("dummy") && !password.Equals("dummy"))
                return null;

            var Token = new UserTokens();
            var ut = new UserTokens()
            {
                EmailId = "",
                GuidId = Guid.NewGuid(),
                UserName = "dummy",                
                Id = Guid.NewGuid(),
            };
            Token = JwtHelpers.GenTokenkey(ut);
            var isTokenValidated = JwtHelpers.ValidateToken(Token.Token);

            
            if (isTokenValidated)
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var jwt = tokenHandler.ReadJwtToken(Token.Token);
                var Name = jwt.Claims.First(claim => claim.Type == "Name").Value;
                _response.Result = Token.Token;

            }
            return _response;
        }
    }

    
}

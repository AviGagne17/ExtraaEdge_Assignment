﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using WebApiMobileStore.Models.Dto;
using WebApiMobileStore.Models.Dtos;
using WebApiMobileStore.Repository;

namespace WebApiMobileStore.Controllers
{
    [Route("api/sales")]
    public class SaleApiController: ControllerBase
    {
        protected ResponseDto _response;
        private ISaleRepository _saleRepository;

        public SaleApiController(ISaleRepository saleRepository)
        {
            _saleRepository = saleRepository;
            this._response = new ResponseDto();
        }

        [HttpGet]
        [Route("SalesRecord")]
        public async Task<object> Get(string fromDate, string toDate)
        {
            try
            {
                IEnumerable<SaleDto> saleDtos = await _saleRepository.GetSaleRecordByDate(fromDate, toDate);
                _response.Result = saleDtos;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages
                     = new List<string>() { ex.ToString() };
            }
            return _response;
        }

        [HttpGet]
        [Route("MonthlySalesReport")]
        public async Task<object> Get(int month, int year)
        {
            try
            {
                
                IEnumerable<ProfitReportDto> ProfitReportDtos = await _saleRepository.GetSaleReportByMonth(month, year);
                _response.Result = ProfitReportDtos;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages
                     = new List<string>() { ex.ToString() };
            }
            return _response;
        }

        [HttpGet]
        [Route("MonthlySalesReportByProduct")]
        public async Task<object> Get(int month, int year, int productId)
        {
            try
            {

                IEnumerable<ProfitReportDto> ProfitReportDtos = await _saleRepository.GetSaleReportByMonthForSpecificProduct(month, year, productId);
                _response.Result = ProfitReportDtos;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages
                     = new List<string>() { ex.ToString() };
            }
            return _response;
        }

        [HttpPost]
        public async Task<object> Post([FromBody] SaleDto saleDto)
        {
            try
            {
                SaleDto model = await _saleRepository.AddSaleRecord(saleDto);
                _response.Result = model;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages
                     = new List<string>() { ex.ToString() };
            }
            return _response;
        }
    }
}

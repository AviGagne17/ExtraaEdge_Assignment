﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System.ComponentModel.DataAnnotations;

namespace WebApiMobileStore.Models
{
    public class ProfitReport
    {
        [Key]
        public int Id { get; set; }
        public int SaleId { get; set; }
        public string SaleMonth { get; set; }
        public int SaleYear { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public double UnitsSold { get; set; }
        public double Discount { get; set; }
        public double Profit { get; set; }

    }
}

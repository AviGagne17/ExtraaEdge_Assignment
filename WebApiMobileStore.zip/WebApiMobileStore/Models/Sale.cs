﻿using System.ComponentModel.DataAnnotations;

namespace WebApiMobileStore.Models
{
    public class Sale
    {
        [Key]
        public int SaleId { get; set; }
        [Required]
        public int ProductId { get; set; }
        [Required]
        public string ProductName { get; set; }
        [Required]
        public string SaleDate { get; set; }
        public string SaleTime { get; set; }
        [Required]
        public string CustomerName { get; set; }
        [Required]
        public string CustomerContact { get; set; }
        [Required]
        public double SellingPrice { get; set; }

        public double Discount { get; set; }

    }
}

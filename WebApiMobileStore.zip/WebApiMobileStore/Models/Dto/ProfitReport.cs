﻿namespace WebApiMobileStore.Models.Dto
{
    public class ProfitReport
    {
    }
}

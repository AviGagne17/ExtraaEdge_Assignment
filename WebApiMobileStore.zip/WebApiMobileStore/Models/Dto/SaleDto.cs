﻿using System.ComponentModel.DataAnnotations;

namespace WebApiMobileStore.Models.Dtos
{
    public class SaleDto
    {
        public int SaleId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string SaleDate { get; set; }
        public string SaleTime { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContact { get; set; }
        public double SellingPrice { get; set; }

        public double Discount { get; set; }
    }
}
